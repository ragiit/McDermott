SET IDENTITY_INSERT [GroupMenus] ON
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6226, 33, 1, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652415', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6227, 33, 2, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652444', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6228, 33, 3, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652446', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6229, 33, 4, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652449', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6230, 33, 5, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652452', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6231, 33, 6, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652454', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6232, 33, 7, '0', '1', '0', '0', '0', N'Argi P', '2024-03-06 14:00:47.7652456', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6233, 33, 8, '1', '1', '1', '1', '1', N'Argi P', '2024-03-06 14:00:47.7652457', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6234, 33, 9, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652459', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6235, 33, 10, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652460', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6236, 33, 11, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652462', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6237, 33, 12, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652464', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6238, 33, 13, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652466', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6239, 33, 14, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652467', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6240, 33, 15, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652469', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6241, 33, 16, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652470', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6242, 33, 17, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652472', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6243, 33, 18, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652473', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6244, 33, 19, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652476', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6245, 33, 20, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652477', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6246, 33, 21, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652479', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6247, 33, 22, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652480', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6248, 33, 23, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652482', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6249, 33, 24, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652483', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6250, 33, 26, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652485', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6251, 33, 27, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652487', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6252, 33, 28, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652488', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6253, 33, 29, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652490', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6254, 33, 30, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652492', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6255, 33, 31, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652493', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6256, 33, 32, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652495', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6257, 33, 34, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652497', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6258, 33, 35, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652498', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6259, 33, 36, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652500', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6260, 33, 37, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652502', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6261, 33, 38, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652503', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6262, 33, 39, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652505', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6263, 33, 40, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652507', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6264, 33, 41, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652508', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6265, 33, 42, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652510', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6266, 33, 43, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652511', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6267, 33, 44, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652513', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6268, 33, 45, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652514', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6269, 33, 46, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652516', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6270, 33, 47, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652517', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6271, 33, 48, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652519', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6272, 33, 49, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652521', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6273, 33, 50, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652522', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6274, 33, 51, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652524', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6275, 33, 52, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652525', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6276, 33, 53, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652527', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6277, 33, 54, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652528', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6278, 33, 55, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652530', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6279, 33, 56, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652531', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6280, 33, 57, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652533', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6281, 33, 58, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652535', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6282, 33, 59, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652536', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6283, 33, 60, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652538', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6284, 33, 61, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652539', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6285, 33, 62, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652541', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6286, 33, 63, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652543', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6287, 33, 64, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652544', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6288, 33, 65, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652546', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6289, 33, 66, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652547', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6290, 33, 67, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652549', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6291, 33, 68, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652550', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6292, 33, 69, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652552', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6293, 33, 71, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652553', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6294, 33, 72, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652555', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6295, 33, 73, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652556', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6296, 33, 74, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652558', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6297, 33, 76, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652559', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6298, 33, 78, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652561', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6299, 33, 1075, '1', '1', '1', '1', '0', N'Argi P', '2024-03-06 14:00:47.7652562', NULL, NULL);
GO
INSERT INTO [GroupMenus] ([Id], [GroupId], [MenuId], [Create], [Read], [Update], [Delete], [Import], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (6300, 33, 1076, '1', '1', '1', '1', '1', N'Argi P', '2024-03-06 14:00:47.7652564', NULL, NULL);
GO
SET IDENTITY_INSERT [GroupMenus] OFF
GO