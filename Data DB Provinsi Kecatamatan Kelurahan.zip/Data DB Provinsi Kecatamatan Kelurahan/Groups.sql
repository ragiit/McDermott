SET IDENTITY_INSERT [Groups] ON
GO
INSERT INTO [Groups] ([Id], [Name], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (33, N'Admin', NULL, '2024-03-05 07:35:50.5582230', N'Argi P', '2024-03-06 14:00:47.4311002');
SET IDENTITY_INSERT [Groups] OFF
GO